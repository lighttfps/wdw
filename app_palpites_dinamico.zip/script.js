
function atualizarPalpites() {
    const palpites = [
        { jogo: "Fortaleza x Sport", palpite: "Mais de 1.5 gols" },
        { jogo: "Bahia x Ceará", palpite: "Ambos marcam - Sim" },
        { jogo: "CRB x Náutico", palpite: "Vitória do CRB" },
        { jogo: "Corinthians x Flamengo", palpite: "Mais de 2.5 gols" },
        { jogo: "Arsenal x Chelsea", palpite: "Ambos marcam - Sim" }
    ];
    
    const container = document.getElementById("palpites");
    container.innerHTML = "";
    
    palpites.forEach(item => {
        const div = document.createElement("div");
        div.className = "palpite";
        div.innerHTML = `<strong>${item.jogo}</strong><br>${item.palpite}`;
        container.appendChild(div);
    });
}

// Atualiza automaticamente ao carregar
window.onload = atualizarPalpites;
